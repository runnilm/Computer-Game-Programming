using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InvaderMovement : MonoBehaviour
{
    public float speed = 5.0f;
    public float speedMult = 1.0f;
    public float xStoppingPoint = 7.0f;
    public float yStoppingPoint = 6.0f;
    public bool moveRight;
    public bool moveLeft;
    public bool dropEvent;

    // Start is called before the first frame update
    void Start()
    {
        Vector2 pos = transform.position;

        pos.x = Mathf.Round(Random.Range(-6.0f, 6.0f));
        pos.y = Mathf.Round(Random.Range(1.0f, 4.5f));

        moveRight = false;
        moveLeft = true;
        speedMult = Random.Range(0.5f, 2.0f);

        transform.position = pos;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Vector2 pos = transform.position;

        if (moveRight)
        {
            if (pos.x <= xStoppingPoint)
            {
                pos.x += Time.deltaTime * speed * speedMult;
            }
            else
            {
                moveRight = false;
                moveLeft = true;
                dropEvent = true;
            }
        }

        if (moveLeft)
        {
            if (pos.x >= -xStoppingPoint)
            {
                pos.x -= Time.deltaTime * speed * speedMult;
            }
            else
            {
                moveRight = true;
                moveLeft = false;
                dropEvent = true;
            }
        }

        if (dropEvent)
        {
            if (pos.y >= -yStoppingPoint)
            {
                pos.y -= 0.5f;
                dropEvent = false;
                transform.position = pos;
            }
            else if (pos.y < -yStoppingPoint)
            {
                Time.timeScale = 0;
                dropEvent = false;
            }
        }

        transform.position = pos;
    }
}