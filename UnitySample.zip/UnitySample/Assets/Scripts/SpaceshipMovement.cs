using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpaceshipMovement : MonoBehaviour {
    public bool offScreenEvent = false;
    public float xStoppingPoint = 7f;
    public float yStoppingPoint = 5f;
    public float speed = 0.01f;
    public bool lose = true;

    public Text myText;

    // Start is called before the first frame update
    void Start() {}

    // Update is called once per frame
    void Update() {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");

        Vector2 pos = transform.position;
        pos.x += h * speed * Time.deltaTime;
        pos.y += v * speed * Time.deltaTime;

        /*if (Input.GetButtonDown("Fire1")) {
            pos.x *= 2;
            pos.y *= 2;
        }*/

        if (pos.y >= yStoppingPoint)
        {
            offScreenEvent = true;
            lose = false;
            Time.timeScale = 0;
        } else if (pos.y <= -yStoppingPoint)
        {
            pos.y = -yStoppingPoint;
        }

        if (pos.x >= xStoppingPoint)
        {
            pos.x = -xStoppingPoint;
        } else if (pos.x <= -xStoppingPoint)
        {
            pos.x = xStoppingPoint;
        }

        transform.position = pos;

        if (Time.timeScale == 0)
        {
            if (lose == true)
            {
                myText.text = "You lose!";
            }
            else if (lose == false)
            {
                myText.text = "You win!";

            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("Trigger -> " + collision.gameObject.name + " collided with " + gameObject.name + " at time " + Time.time);
        lose = true;
        Time.timeScale = 0;
    }
}
